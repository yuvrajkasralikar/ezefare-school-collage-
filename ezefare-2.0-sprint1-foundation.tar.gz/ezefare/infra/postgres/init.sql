-- Runtime role is NOT a superuser, so RLS tenant isolation is actually enforced.
CREATE ROLE ezefare_app LOGIN PASSWORD 'ezefare_app' NOSUPERUSER NOBYPASSRLS;
GRANT CONNECT ON DATABASE ezefare TO ezefare_app;
GRANT USAGE ON SCHEMA public TO ezefare_app;
ALTER DEFAULT PRIVILEGES FOR ROLE ezefare IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ezefare_app;
ALTER DEFAULT PRIVILEGES FOR ROLE ezefare IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO ezefare_app;
