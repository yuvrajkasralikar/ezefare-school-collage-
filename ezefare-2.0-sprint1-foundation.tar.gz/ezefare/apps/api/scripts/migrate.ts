import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import pg from 'pg';

const url = process.env.MIGRATE_DATABASE_URL ?? process.env.DATABASE_URL;
if (!url) throw new Error('MIGRATE_DATABASE_URL (owner role) is required');
const dir = join(import.meta.dirname, '..', '..', '..', 'migrations');

const c = new pg.Client({ connectionString: url });
await c.connect();
await c.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
const done = new Set((await c.query('SELECT name FROM schema_migrations')).rows.map((r) => r.name));

for (const f of readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
  if (done.has(f)) continue;
  console.log('applying', f);
  try {
    await c.query('BEGIN');
    await c.query(readFileSync(join(dir, f), 'utf8'));
    await c.query('INSERT INTO schema_migrations (name) VALUES ($1)', [f]);
    await c.query('COMMIT');
  } catch (e) { await c.query('ROLLBACK'); throw e; }
}
await c.end();
console.log('migrations up to date');
