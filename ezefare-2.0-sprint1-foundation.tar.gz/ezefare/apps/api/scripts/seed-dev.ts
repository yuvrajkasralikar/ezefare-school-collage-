// Creates the first platform Super Admin (dev/bootstrap). Runs as owner role.
import pg from 'pg';
import { hashPassword } from '../src/modules/iam/password.js';

const url = process.env.MIGRATE_DATABASE_URL ?? process.env.DATABASE_URL;
const email = process.env.SEED_ADMIN_EMAIL, pw = process.env.SEED_ADMIN_PASSWORD;
if (!url || !email || !pw) throw new Error('MIGRATE_DATABASE_URL, SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD required');

const c = new pg.Client({ connectionString: url });
await c.connect();
await c.query('BEGIN');
await c.query(`SELECT set_config('app.is_platform','true',true)`);
const u = await c.query(
  `INSERT INTO users (email, full_name, password_hash, status) VALUES ($1,'Platform Super Admin',$2,'ACTIVE')
   ON CONFLICT (lower(email)) WHERE email IS NOT NULL DO UPDATE SET password_hash = EXCLUDED.password_hash RETURNING id`,
  [email, await hashPassword(pw)]);
await c.query(
  `INSERT INTO role_assignments (user_id, role_id, scope_type)
   SELECT $1, id, 'platform' FROM roles WHERE code='super_admin'
   AND NOT EXISTS (SELECT 1 FROM role_assignments ra JOIN roles r ON r.id=ra.role_id
                    WHERE ra.user_id=$1 AND r.code='super_admin' AND ra.revoked_at IS NULL)`, [u.rows[0].id]);
await c.query(
  `INSERT INTO audit_log (actor_type, action, entity_type, entity_id) VALUES ('system','platform.super_admin_seeded','user',$1)`,
  [u.rows[0].id]);
await c.query('COMMIT');
await c.end();
console.log('seeded super admin', email);
