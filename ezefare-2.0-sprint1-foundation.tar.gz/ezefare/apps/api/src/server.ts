import { env } from './config/env.js';
import { buildApp } from './app.js';
import { pool } from './platform/db.js';

const app = buildApp();
await app.listen({ port: env.PORT, host: '0.0.0.0' });

for (const sig of ['SIGINT', 'SIGTERM'] as const) {
  process.on(sig, async () => { await app.close(); await pool.end(); process.exit(0); });
}
