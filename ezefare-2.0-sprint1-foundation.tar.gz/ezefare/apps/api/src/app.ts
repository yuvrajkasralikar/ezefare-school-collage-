import { randomUUID } from 'node:crypto';
import Fastify from 'fastify';
import { pool } from './platform/db.js';
import { errorHandler } from './platform/errors.js';
import { authRoutes } from './modules/iam/auth.routes.js';
import { organizationRoutes } from './modules/organizations/organizations.routes.js';

export function buildApp() {
  const app = Fastify({
    logger: { level: process.env.LOG_LEVEL ?? 'info', redact: ['req.headers.authorization'] },
    // Correlation ID (blueprint §18): honour inbound header, else generate; echoed on every response.
    genReqId: (req) => (req.headers['x-request-id'] as string) || randomUUID(),
    bodyLimit: 1_048_576,
  });
  app.addHook('onSend', async (req, reply) => { reply.header('x-request-id', req.id); });
  app.setErrorHandler(errorHandler);
  app.setNotFoundHandler((req, reply) =>
    reply.status(404).send({ error: { code: 'NOT_FOUND', message: 'Route not found', request_id: req.id } }));

  app.get('/health', async () => ({ status: 'ok' }));
  app.get('/ready', async (_req, reply) => {
    try { await pool.query('SELECT 1'); return { status: 'ready' }; }
    catch { return reply.status(503).send({ status: 'unavailable' }); }
  });

  app.register(authRoutes);
  app.register(organizationRoutes);
  return app;
}
