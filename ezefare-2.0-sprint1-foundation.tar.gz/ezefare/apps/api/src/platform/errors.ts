import type { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';

/** Structured error (blueprint §18): { error: { code, message, details?, request_id } } */
export class AppError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
  }
}

export const Errors = {
  unauthenticated: () => new AppError(401, 'UNAUTHENTICATED', 'Authentication required'),
  forbidden: () => new AppError(403, 'FORBIDDEN', 'You do not have permission for this action'),
  notFound: (what = 'Resource') => new AppError(404, 'NOT_FOUND', `${what} not found`),
  conflict: (code: string, msg: string) => new AppError(409, code, msg),
};

export function errorHandler(err: FastifyError | Error, req: FastifyRequest, reply: FastifyReply) {
  const requestId = req.id;
  if (err instanceof AppError) {
    return reply.status(err.status).send({
      error: { code: err.code, message: err.message, details: err.details, request_id: requestId },
    });
  }
  if (err instanceof ZodError) {
    return reply.status(422).send({
      error: { code: 'VALIDATION_FAILED', message: 'Invalid input', details: err.flatten(), request_id: requestId },
    });
  }
  const status = (err as FastifyError).statusCode ?? 500;
  if (status >= 500) req.log.error({ err }, 'unhandled error');
  return reply.status(status).send({
    error: {
      code: status >= 500 ? 'INTERNAL_ERROR' : 'BAD_REQUEST',
      message: status >= 500 ? 'Unexpected error' : err.message,
      request_id: requestId,
    },
  });
}
