import { z } from 'zod';

/** Keyset (cursor) pagination: stable under inserts, no OFFSET scans. */
export const pageQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(25),
  cursor: z.string().optional(),
});

export interface Cursor { t: string; id: string }

export const encodeCursor = (c: Cursor) => Buffer.from(JSON.stringify(c)).toString('base64url');

export function decodeCursor(raw?: string): Cursor | null {
  if (!raw) return null;
  try {
    const c = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
    return typeof c.t === 'string' && typeof c.id === 'string' ? c : null;
  } catch { return null; }
}

export function pageResult<T extends { id: string; created_at: Date }>(rows: T[], limit: number) {
  const hasMore = rows.length > limit;
  const data = hasMore ? rows.slice(0, limit) : rows;
  const last = data[data.length - 1];
  return {
    data,
    page: { limit, next_cursor: hasMore && last ? encodeCursor({ t: last.created_at.toISOString(), id: last.id }) : null },
  };
}
