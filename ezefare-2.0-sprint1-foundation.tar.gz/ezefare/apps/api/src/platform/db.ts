import pg from 'pg';
import { env } from '../config/env.js';

export const pool = new pg.Pool({ connectionString: env.DATABASE_URL, max: 10 });

export interface TenantCtx {
  orgId?: string | null;
  /** Platform context bypasses tenant RLS. Use ONLY for platform-level operations and auth bootstrap. */
  isPlatform?: boolean;
  userId?: string | null;
}

/**
 * Runs fn in a transaction with tenant context applied to Postgres session settings, so
 * Row Level Security enforces isolation even if application code forgets a WHERE clause.
 */
export async function withTx<T>(ctx: TenantCtx, fn: (c: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `SELECT set_config('app.current_org', $1, true),
              set_config('app.is_platform', $2, true),
              set_config('app.current_user', $3, true)`,
      [ctx.orgId ?? '', ctx.isPlatform ? 'true' : 'false', ctx.userId ?? ''],
    );
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

/** Explicit, greppable name for the few places that legitimately need cross-tenant access. */
export const withPlatformTx = <T>(fn: (c: pg.PoolClient) => Promise<T>, userId?: string) =>
  withTx({ isPlatform: true, userId }, fn);
