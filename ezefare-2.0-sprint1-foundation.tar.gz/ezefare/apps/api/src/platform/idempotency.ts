import { createHash } from 'node:crypto';
import type pg from 'pg';
import { Errors } from './errors.js';

export interface IdemResult { status: number; body: unknown; replayed: boolean }

/**
 * Wraps a mutation so retries with the same Idempotency-Key replay the stored response.
 * Same key + different payload => 409. Runs inside the same transaction as the mutation,
 * so the key and the effect commit (or roll back) together.
 */
export async function idempotent(
  c: pg.PoolClient,
  scope: string,
  key: string | undefined,
  payload: unknown,
  run: () => Promise<{ status: number; body: unknown }>,
): Promise<IdemResult> {
  if (!key) return { ...(await run()), replayed: false };
  const hash = createHash('sha256').update(JSON.stringify(payload ?? null)).digest('hex');
  const ex = await c.query(
    'SELECT request_hash, response_status, response_body FROM idempotency_keys WHERE scope=$1 AND key=$2',
    [scope, key],
  );
  if (ex.rowCount) {
    const row = ex.rows[0];
    if (row.request_hash !== hash) {
      throw Errors.conflict('IDEMPOTENCY_KEY_REUSED', 'Idempotency-Key was already used with a different request');
    }
    return { status: row.response_status, body: row.response_body, replayed: true };
  }
  const out = await run();
  await c.query(
    'INSERT INTO idempotency_keys (scope, key, request_hash, response_status, response_body) VALUES ($1,$2,$3,$4,$5)',
    [scope, key, hash, out.status, JSON.stringify(out.body)],
  );
  return { ...out, replayed: false };
}
