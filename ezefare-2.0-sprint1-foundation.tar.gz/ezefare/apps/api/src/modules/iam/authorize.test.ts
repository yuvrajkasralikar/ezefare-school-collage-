import { test } from 'node:test';
import assert from 'node:assert/strict';
import { authorize, visibleOrganizationIds, type RoleAssignment } from './authorize.js';
import { canCrewReadTripStudent, canParentReadStudent, canVendorManageVehicle, type RelationshipRepo } from './relationship.js';

const ORG_A = 'org-a', ORG_B = 'org-b', CAMPUS_1 = 'campus-1', CAMPUS_2 = 'campus-2';
type Spec = Partial<Omit<RoleAssignment, 'permissions'>> & { permissions: string[] };
const mk = ({ permissions, ...rest }: Spec): RoleAssignment => ({
  roleCode: 'x', scopeType: 'organization', scopeId: ORG_A, organizationId: ORG_A, ...rest,
  permissions: new Set(permissions),
});

test('platform scope acts on any tenant', () => {
  const a = mk({ scopeType: 'platform', scopeId: null, organizationId: null, permissions: ['org:manage'] });
  assert.equal(authorize([a], 'org:manage', {}), true);
  assert.equal(authorize([a], 'org:manage', { organizationId: ORG_B }), true);
});

test('organization scope is confined to its own tenant (role != scope)', () => {
  const a = mk({ permissions: ['student:read'] });
  assert.equal(authorize([a], 'student:read', { organizationId: ORG_A, campusId: CAMPUS_1 }), true);
  assert.equal(authorize([a], 'student:read', { organizationId: ORG_B }), false);
});

test('missing permission is denied even with matching scope', () => {
  const a = mk({ permissions: ['student:read'] });
  assert.equal(authorize([a], 'student:write', { organizationId: ORG_A }), false);
});

test('campus scope covers only that campus', () => {
  const a = mk({ scopeType: 'campus', scopeId: CAMPUS_1, permissions: ['transport:manage'] });
  assert.equal(authorize([a], 'transport:manage', { organizationId: ORG_A, campusId: CAMPUS_1 }), true);
  assert.equal(authorize([a], 'transport:manage', { organizationId: ORG_A, campusId: CAMPUS_2 }), false);
  assert.equal(authorize([a], 'transport:manage', { organizationId: ORG_A }), false);
});

test('non-platform assignment with no target org is denied (fail closed)', () => {
  const a = mk({ permissions: ['org:read'] });
  assert.equal(authorize([a], 'org:read', {}), false);
});

test('resource scope matches exact resource only (e.g. driver on one trip)', () => {
  const a = mk({ scopeType: 'resource', scopeId: 'trip-9', permissions: ['trip:operate'] });
  assert.equal(authorize([a], 'trip:operate', { organizationId: ORG_A, resourceId: 'trip-9' }), true);
  assert.equal(authorize([a], 'trip:operate', { organizationId: ORG_A, resourceId: 'trip-10' }), false);
});

test('a user with multiple assignments gets the union', () => {
  const t = mk({ scopeType: 'campus', scopeId: CAMPUS_1, permissions: ['attendance:write'] });
  const f = mk({ scopeType: 'campus', scopeId: CAMPUS_2, permissions: ['finance:manage'] });
  assert.equal(authorize([t, f], 'finance:manage', { organizationId: ORG_A, campusId: CAMPUS_2 }), true);
  assert.equal(authorize([t, f], 'finance:manage', { organizationId: ORG_A, campusId: CAMPUS_1 }), false);
});

test('visibleOrganizationIds', () => {
  assert.equal(visibleOrganizationIds([mk({ scopeType: 'platform', scopeId: null, organizationId: null, permissions: [] })]), null);
  assert.deepEqual(visibleOrganizationIds([mk({ permissions: [] }), mk({ permissions: [] })]), [ORG_A]);
});

const repo = (o: Partial<RelationshipRepo>): RelationshipRepo => ({
  hasActiveGuardianLink: async () => false, isAssignedToTrip: async () => false,
  studentIsOnTrip: async () => false, vehicleAuthorizedForVendor: async () => false, ...o,
});

test('Appendix B: parent reads student only with active guardian link', async () => {
  assert.equal(await canParentReadStudent(repo({ hasActiveGuardianLink: async () => true }), 'u', 's'), true);
  assert.equal(await canParentReadStudent(repo({}), 'u', 's'), false);
});

test('Appendix B: driver/attendant reads student only when assigned to the trip AND student is on it', async () => {
  const both = repo({ isAssignedToTrip: async () => true, studentIsOnTrip: async () => true });
  const unassigned = repo({ studentIsOnTrip: async () => true });
  const notOnTrip = repo({ isAssignedToTrip: async () => true });
  assert.equal(await canCrewReadTripStudent(both, 'u', 'driver', 't', 's'), true);
  assert.equal(await canCrewReadTripStudent(unassigned, 'u', 'attendant', 't', 's'), false);
  assert.equal(await canCrewReadTripStudent(notOnTrip, 'u', 'driver', 't', 's'), false);
});

test('Appendix B: vendor admin manages only authorized vehicles', async () => {
  assert.equal(await canVendorManageVehicle(repo({ vehicleAuthorizedForVendor: async () => true }), 'v', 'veh'), true);
  assert.equal(await canVendorManageVehicle(repo({}), 'v', 'veh'), false);
});
