import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { Errors } from '../../platform/errors.js';
import { authenticate } from './guard.js';
import * as auth from './auth.service.js';

const loginBody = z.object({ email: z.string().email(), password: z.string().min(1).max(200) });
const refreshBody = z.object({ refresh_token: z.string().min(10) });

export async function authRoutes(app: FastifyInstance) {
  const meta = (req: import('fastify').FastifyRequest) => ({ ip: req.ip, userAgent: req.headers['user-agent'], requestId: req.id });

  app.post('/v1/auth/login', async (req) => {
    const body = loginBody.parse(req.body);
    const tokens = await auth.login(body.email, body.password, meta(req));
    if (!tokens) throw Errors.unauthenticated(); // same response for unknown user / wrong password
    return tokens;
  });

  app.post('/v1/auth/refresh', async (req) => {
    const body = refreshBody.parse(req.body);
    const tokens = await auth.refresh(body.refresh_token, meta(req));
    if (!tokens) throw Errors.unauthenticated();
    return tokens;
  });

  app.post('/v1/auth/logout', { preHandler: authenticate }, async (req, reply) => {
    await auth.logout(req.auth!.sessionId, req.auth!.userId, meta(req));
    return reply.status(204).send();
  });

  app.get('/v1/me', { preHandler: authenticate }, async (req) => ({
    user_id: req.auth!.userId,
    assignments: req.auth!.assignments.map((a) => ({
      role: a.roleCode, scope_type: a.scopeType, scope_id: a.scopeId, organization_id: a.organizationId,
      permissions: [...a.permissions].sort(),
    })),
  }));
}
