import type { FastifyReply, FastifyRequest } from 'fastify';
import { Errors } from '../../platform/errors.js';
import { authenticateAccessToken, type AuthContext } from './auth.service.js';
import { authorize, type Target } from './authorize.js';

declare module 'fastify' {
  interface FastifyRequest { auth?: AuthContext }
}

export async function authenticate(req: FastifyRequest, _reply: FastifyReply) {
  const h = req.headers.authorization;
  const token = h?.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) throw Errors.unauthenticated();
  const ctx = await authenticateAccessToken(token);
  if (!ctx) throw Errors.unauthenticated();
  req.auth = ctx;
}

/** Route guard: authenticate, then evaluate permission against the (resolved) target. Fail closed. */
export function requirePermission(permission: string, target: (req: FastifyRequest) => Target = () => ({})) {
  return async (req: FastifyRequest, reply: FastifyReply) => {
    await authenticate(req, reply);
    if (!authorize(req.auth!.assignments, permission, target(req))) throw Errors.forbidden();
  };
}
