/**
 * Authorization core (blueprint §3): user -> role assignment -> scope -> permission -> action.
 * Pure functions, no I/O: easy to test exhaustively and safe to reuse in workers.
 */
export type ScopeType = 'platform' | 'organization' | 'campus' | 'resource';

export interface RoleAssignment {
  roleCode: string;
  permissions: ReadonlySet<string>;
  scopeType: ScopeType;
  scopeId: string | null;
  organizationId: string | null;
}

/** The thing being acted on, fully resolved by the caller (always include organizationId when it exists). */
export interface Target {
  organizationId?: string | null;
  campusId?: string | null;
  resourceId?: string | null;
}

export function authorize(assignments: readonly RoleAssignment[], permission: string, target: Target = {}): boolean {
  for (const a of assignments) {
    if (!a.permissions.has(permission)) continue;

    if (a.scopeType === 'platform') return true;

    // Tenant boundary: a non-platform assignment can never act on another organization.
    if (!target.organizationId || a.organizationId !== target.organizationId) continue;

    if (a.scopeType === 'organization') return true;
    if (a.scopeType === 'campus' && target.campusId && a.scopeId === target.campusId) return true;
    if (a.scopeType === 'resource' && target.resourceId && a.scopeId === target.resourceId) return true;
  }
  return false;
}

/** Organizations a user can see (for list endpoints). null => all (platform). */
export function visibleOrganizationIds(assignments: readonly RoleAssignment[]): string[] | null {
  if (assignments.some((a) => a.scopeType === 'platform')) return null;
  return [...new Set(assignments.map((a) => a.organizationId).filter((x): x is string => !!x))];
}
