/**
 * Relationship-based rules (blueprint Appendix B). Parents, drivers, attendants and vendors do not get
 * broad role scope; access derives from a live relationship (guardian link, trip assignment, vehicle ownership).
 * The repo is an interface so the Student/Transport domains plug in their queries later.
 */
export interface RelationshipRepo {
  hasActiveGuardianLink(userId: string, studentId: string): Promise<boolean>;
  isAssignedToTrip(userId: string, tripId: string, as: 'driver' | 'attendant'): Promise<boolean>;
  studentIsOnTrip(studentId: string, tripId: string): Promise<boolean>;
  vehicleAuthorizedForVendor(vendorOrganizationId: string, vehicleId: string): Promise<boolean>;
}

export const canParentReadStudent = (r: RelationshipRepo, userId: string, studentId: string) =>
  r.hasActiveGuardianLink(userId, studentId);

export async function canCrewReadTripStudent(
  r: RelationshipRepo, userId: string, as: 'driver' | 'attendant', tripId: string, studentId: string,
): Promise<boolean> {
  return (await r.isAssignedToTrip(userId, tripId, as)) && (await r.studentIsOnTrip(studentId, tripId));
}

export const canVendorManageVehicle = (r: RelationshipRepo, vendorOrganizationId: string, vehicleId: string) =>
  r.vehicleAuthorizedForVendor(vendorOrganizationId, vehicleId);
