import jwt from 'jsonwebtoken';
import type pg from 'pg';
import { env } from '../../config/env.js';
import { withPlatformTx } from '../../platform/db.js';
import { writeAudit } from '../audit/audit.js';
import type { RoleAssignment, ScopeType } from './authorize.js';
import { newRefreshToken, sha256, verifyPassword } from './password.js';

export interface AuthContext { userId: string; sessionId: string; assignments: RoleAssignment[] }
export interface Tokens { access_token: string; refresh_token: string; token_type: 'Bearer'; expires_in: number }
interface Meta { ip?: string; userAgent?: string; requestId?: string }

const signAccess = (userId: string, sessionId: string) =>
  jwt.sign({ sid: sessionId }, env.JWT_SECRET, { subject: userId, expiresIn: env.ACCESS_TOKEN_TTL_SECONDS, algorithm: 'HS256' });

export function verifyAccess(token: string): { userId: string; sessionId: string } | null {
  try {
    const p = jwt.verify(token, env.JWT_SECRET, { algorithms: ['HS256'] }) as jwt.JwtPayload;
    return p.sub && typeof p.sid === 'string' ? { userId: p.sub, sessionId: p.sid } : null;
  } catch { return null; }
}

/** Platform context is required because assignments span tenants; this is auth bootstrap only. */
export async function loadAssignments(c: pg.PoolClient, userId: string): Promise<RoleAssignment[]> {
  const { rows } = await c.query(
    `SELECT r.code AS role_code, ra.scope_type, ra.scope_id, ra.organization_id,
            COALESCE(array_agg(p.code) FILTER (WHERE p.code IS NOT NULL), '{}') AS permissions
       FROM role_assignments ra
       JOIN roles r ON r.id = ra.role_id
       LEFT JOIN role_permissions rp ON rp.role_id = r.id
       LEFT JOIN permissions p ON p.id = rp.permission_id
      WHERE ra.user_id = $1 AND ra.revoked_at IS NULL
      GROUP BY ra.id, r.code`,
    [userId],
  );
  return rows.map((x) => ({
    roleCode: x.role_code, scopeType: x.scope_type as ScopeType, scopeId: x.scope_id,
    organizationId: x.organization_id, permissions: new Set<string>(x.permissions),
  }));
}

export async function authenticateAccessToken(token: string): Promise<AuthContext | null> {
  const claims = verifyAccess(token);
  if (!claims) return null;
  return withPlatformTx(async (c) => {
    const s = await c.query(
      `SELECT 1 FROM sessions s JOIN users u ON u.id = s.user_id
        WHERE s.id=$1 AND s.user_id=$2 AND s.revoked_at IS NULL AND s.expires_at > now() AND u.status='ACTIVE'`,
      [claims.sessionId, claims.userId],
    );
    if (!s.rowCount) return null;
    return { userId: claims.userId, sessionId: claims.sessionId, assignments: await loadAssignments(c, claims.userId) };
  });
}

async function issueSession(c: pg.PoolClient, userId: string, meta: Meta): Promise<Tokens> {
  const refresh = newRefreshToken();
  const { rows } = await c.query(
    `INSERT INTO sessions (user_id, refresh_token_hash, user_agent, ip, expires_at)
     VALUES ($1,$2,$3,$4, now() + make_interval(days => $5)) RETURNING id`,
    [userId, sha256(refresh), meta.userAgent ?? null, meta.ip ?? null, env.REFRESH_TOKEN_TTL_DAYS],
  );
  return { access_token: signAccess(userId, rows[0].id), refresh_token: refresh, token_type: 'Bearer', expires_in: env.ACCESS_TOKEN_TTL_SECONDS };
}

export async function login(email: string, password: string, meta: Meta): Promise<Tokens | null> {
  return withPlatformTx(async (c) => {
    const { rows } = await c.query(
      `SELECT id, password_hash, status FROM users WHERE lower(email) = lower($1)`, [email]);
    const u = rows[0];
    const ok = !!u && u.status === 'ACTIVE' && !!u.password_hash && (await verifyPassword(password, u.password_hash));
    await writeAudit(c, {
      actorUserId: u?.id ?? null, actorType: u ? 'user' : 'system', action: ok ? 'auth.login_succeeded' : 'auth.login_failed',
      entityType: 'user', entityId: u?.id ?? null, requestId: meta.requestId, ip: meta.ip,
      metadata: ok ? {} : { email_attempted: email },
    });
    return ok ? issueSession(c, u.id, meta) : null; // audit commits either way
  });
}

export async function refresh(refreshToken: string, meta: Meta): Promise<Tokens | null> {
  return withPlatformTx(async (c) => {
    const { rows } = await c.query(
      `SELECT s.id, s.user_id FROM sessions s JOIN users u ON u.id = s.user_id
        WHERE s.refresh_token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at > now() AND u.status='ACTIVE'
        FOR UPDATE OF s`, [sha256(refreshToken)]);
    const s = rows[0];
    if (!s) return null;
    const next = newRefreshToken(); // rotation: old refresh token stops working immediately
    await c.query('UPDATE sessions SET refresh_token_hash=$1 WHERE id=$2', [sha256(next), s.id]);
    return { access_token: signAccess(s.user_id, s.id), refresh_token: next, token_type: 'Bearer', expires_in: env.ACCESS_TOKEN_TTL_SECONDS } as Tokens;
  });
}

export async function logout(sessionId: string, userId: string, meta: Meta): Promise<void> {
  await withPlatformTx(async (c) => {
    await c.query('UPDATE sessions SET revoked_at = now() WHERE id=$1 AND user_id=$2', [sessionId, userId]);
    await writeAudit(c, { actorUserId: userId, action: 'auth.logout', entityType: 'session', entityId: sessionId, requestId: meta.requestId, ip: meta.ip });
  });
}
