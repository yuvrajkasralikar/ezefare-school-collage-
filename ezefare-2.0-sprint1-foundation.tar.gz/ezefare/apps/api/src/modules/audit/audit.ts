import type pg from 'pg';

export interface AuditEntry {
  organizationId?: string | null;
  actorUserId?: string | null;
  actorType?: 'user' | 'system' | 'device' | 'webhook';
  action: string;            // e.g. 'organization.created'
  entityType: string;
  entityId?: string | null;
  requestId?: string;
  ip?: string;
  before?: unknown;
  after?: unknown;
  metadata?: Record<string, unknown>;
}

/** Writes in the caller's transaction: the audited change and its audit record commit atomically. */
export async function writeAudit(c: pg.PoolClient, e: AuditEntry): Promise<void> {
  await c.query(
    `INSERT INTO audit_log (organization_id, actor_user_id, actor_type, action, entity_type, entity_id,
                            request_id, ip, before, after, metadata)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [
      e.organizationId ?? null, e.actorUserId ?? null, e.actorType ?? 'user', e.action, e.entityType,
      e.entityId ?? null, e.requestId ?? null, e.ip ?? null,
      e.before === undefined ? null : JSON.stringify(e.before),
      e.after === undefined ? null : JSON.stringify(e.after),
      JSON.stringify(e.metadata ?? {}),
    ],
  );
}
