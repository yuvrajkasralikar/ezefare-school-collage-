import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppError, Errors } from '../../platform/errors.js';
import { withPlatformTx, withTx } from '../../platform/db.js';
import { idempotent } from '../../platform/idempotency.js';
import { decodeCursor, pageQuery, pageResult } from '../../platform/pagination.js';
import { writeAudit } from '../audit/audit.js';
import { visibleOrganizationIds } from '../iam/authorize.js';
import { authenticate, requirePermission } from '../iam/guard.js';

const uuid = z.string().uuid();
const orgBody = z.object({
  name: z.string().min(2).max(200),
  slug: z.string().regex(/^[a-z0-9][a-z0-9-]{1,62}$/),
  type: z.enum(['school', 'college', 'group', 'vendor']),
  parent_organization_id: uuid.optional(),
});
const campusBody = z.object({
  code: z.string().regex(/^[A-Za-z0-9_-]{1,32}$/),
  name: z.string().min(2).max(200),
  timezone: z.string().default('Asia/Kolkata'),
});
const orgParams = z.object({ orgId: uuid });

const uniqueViolation = (e: unknown) => (e as { code?: string }).code === '23505';

export async function organizationRoutes(app: FastifyInstance) {
  // Platform-only: target {} can only be satisfied by a platform-scope assignment.
  app.post('/v1/organizations', { preHandler: requirePermission('org:manage') }, async (req, reply) => {
    const body = orgBody.parse(req.body);
    const key = req.headers['idempotency-key'] as string | undefined;
    try {
      const out = await withPlatformTx(async (c) =>
        idempotent(c, 'platform', key, body, async () => {
          const { rows } = await c.query(
            `INSERT INTO organizations (name, slug, type, parent_organization_id) VALUES ($1,$2,$3,$4) RETURNING *`,
            [body.name, body.slug, body.type, body.parent_organization_id ?? null]);
          await writeAudit(c, { organizationId: rows[0].id, actorUserId: req.auth!.userId, action: 'organization.created',
            entityType: 'organization', entityId: rows[0].id, requestId: req.id, ip: req.ip, after: rows[0] });
          return { status: 201, body: rows[0] };
        }), req.auth!.userId);
      if (out.replayed) reply.header('Idempotent-Replayed', 'true');
      return reply.status(out.status).send(out.body);
    } catch (e) {
      if (uniqueViolation(e)) throw Errors.conflict('SLUG_TAKEN', 'Organization slug already exists');
      throw e;
    }
  });

  app.get('/v1/organizations', { preHandler: authenticate }, async (req) => {
    const q = pageQuery.parse(req.query);
    const cur = decodeCursor(q.cursor);
    const visible = visibleOrganizationIds(req.auth!.assignments); // null => platform (all)
    const rows = await withPlatformTx(async (c) =>
      (await c.query(
        `SELECT * FROM organizations
          WHERE ($1::uuid[] IS NULL OR id = ANY($1))
            AND ($2::timestamptz IS NULL OR (created_at, id) > ($2, $3::uuid))
          ORDER BY created_at, id LIMIT $4`,
        [visible, cur?.t ?? null, cur?.id ?? null, q.limit + 1])).rows, req.auth!.userId);
    return pageResult(rows, q.limit);
  });

  app.get('/v1/organizations/:orgId', {
    preHandler: requirePermission('org:read', (r) => ({ organizationId: (r.params as { orgId?: string }).orgId })),
  }, async (req) => {
    const { orgId } = orgParams.parse(req.params);
    const row = await withTx({ orgId, userId: req.auth!.userId }, async (c) =>
      (await c.query('SELECT * FROM organizations WHERE id=$1', [orgId])).rows[0]);
    if (!row) throw Errors.notFound('Organization');
    return row;
  });

  app.post('/v1/organizations/:orgId/campuses', {
    preHandler: requirePermission('campus:manage', (r) => ({ organizationId: (r.params as { orgId?: string }).orgId })),
  }, async (req, reply) => {
    const { orgId } = orgParams.parse(req.params);
    const body = campusBody.parse(req.body);
    const key = req.headers['idempotency-key'] as string | undefined;
    try {
      const out = await withTx({ orgId, userId: req.auth!.userId }, async (c) =>
        idempotent(c, `org:${orgId}`, key, body, async () => {
          const { rows } = await c.query(
            `INSERT INTO campuses (organization_id, code, name, timezone) VALUES ($1,$2,$3,$4) RETURNING *`,
            [orgId, body.code, body.name, body.timezone]);
          await writeAudit(c, { organizationId: orgId, actorUserId: req.auth!.userId, action: 'campus.created',
            entityType: 'campus', entityId: rows[0].id, requestId: req.id, ip: req.ip, after: rows[0] });
          return { status: 201, body: rows[0] };
        }));
      if (out.replayed) reply.header('Idempotent-Replayed', 'true');
      return reply.status(out.status).send(out.body);
    } catch (e) {
      if (uniqueViolation(e)) throw Errors.conflict('CAMPUS_CODE_TAKEN', 'Campus code already exists in this organization');
      if ((e as { code?: string }).code === '23503') throw new AppError(404, 'NOT_FOUND', 'Organization not found');
      throw e;
    }
  });

  app.get('/v1/organizations/:orgId/campuses', {
    preHandler: requirePermission('org:read', (r) => ({ organizationId: (r.params as { orgId?: string }).orgId })),
  }, async (req) => {
    const { orgId } = orgParams.parse(req.params);
    const q = pageQuery.parse(req.query);
    const cur = decodeCursor(q.cursor);
    const rows = await withTx({ orgId, userId: req.auth!.userId }, async (c) =>
      (await c.query(
        `SELECT * FROM campuses WHERE ($1::timestamptz IS NULL OR (created_at, id) > ($1, $2::uuid))
          ORDER BY created_at, id LIMIT $3`, [cur?.t ?? null, cur?.id ?? null, q.limit + 1])).rows);
    return pageResult(rows, q.limit);
  });
}
