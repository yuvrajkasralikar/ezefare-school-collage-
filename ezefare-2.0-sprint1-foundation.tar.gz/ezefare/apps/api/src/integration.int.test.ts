/**
 * Integration tests against a real Postgres (RLS needs a real DB). Skipped unless INTEGRATION=1.
 * Requires: DATABASE_URL (app role), MIGRATE_DATABASE_URL (owner), SEED_ADMIN_EMAIL/PASSWORD seeded.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';

const run = process.env.INTEGRATION === '1';
const T = (name: string, fn: () => Promise<void>) => test(name, { skip: !run }, fn);

let app: Awaited<ReturnType<typeof import('./app.js').buildApp>>;
let owner: pg.Client;
let admin = '', ownerA = '';
const ids: Record<string, string> = {};
const uniq = Date.now().toString(36);

const call = async (method: 'GET' | 'POST', url: string, token?: string, payload?: object, headers: Record<string, string> = {}) => {
  const r = await app.inject({ method, url, payload, headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers } });
  return { status: r.statusCode, body: r.body ? JSON.parse(r.body) : null, headers: r.headers };
};

before(async () => {
  if (!run) return;
  app = (await import('./app.js')).buildApp();
  owner = new pg.Client({ connectionString: process.env.MIGRATE_DATABASE_URL });
  await owner.connect();
});
after(async () => {
  if (!run) return;
  await owner.end();
  await app.close();
  await (await import('./platform/db.js')).pool.end();
});

T('super admin logs in; bad password is rejected and audited', async () => {
  const bad = await call('POST', '/v1/auth/login', undefined, { email: process.env.SEED_ADMIN_EMAIL, password: 'wrong' });
  assert.equal(bad.status, 401);
  const ok = await call('POST', '/v1/auth/login', undefined, { email: process.env.SEED_ADMIN_EMAIL, password: process.env.SEED_ADMIN_PASSWORD });
  assert.equal(ok.status, 200);
  admin = ok.body.access_token;
  const { rows } = await owner.query(`SELECT count(*)::int n FROM audit_log WHERE action='auth.login_failed'`);
  assert.ok(rows[0].n >= 1);
});

T('create two orgs; idempotent retry replays, payload change conflicts', async () => {
  const a = await call('POST', '/v1/organizations', admin, { name: 'School A', slug: `a-${uniq}`, type: 'school' }, { 'idempotency-key': `k-${uniq}` });
  assert.equal(a.status, 201); ids.orgA = a.body.id;
  const again = await call('POST', '/v1/organizations', admin, { name: 'School A', slug: `a-${uniq}`, type: 'school' }, { 'idempotency-key': `k-${uniq}` });
  assert.equal(again.status, 201);
  assert.equal(again.body.id, ids.orgA);
  assert.equal(again.headers['idempotent-replayed'], 'true');
  const clash = await call('POST', '/v1/organizations', admin, { name: 'Other', slug: `x-${uniq}`, type: 'school' }, { 'idempotency-key': `k-${uniq}` });
  assert.equal(clash.status, 409);
  const b = await call('POST', '/v1/organizations', admin, { name: 'College B', slug: `b-${uniq}`, type: 'college' });
  assert.equal(b.status, 201); ids.orgB = b.body.id;
  const dup = await call('POST', '/v1/organizations', admin, { name: 'Dup', slug: `b-${uniq}`, type: 'college' });
  assert.equal(dup.status, 409);
});

T('org-scoped owner can act in own tenant only', async () => {
  const email = `owner-${uniq}@a.test`;
  const { hashPassword } = await import('./modules/iam/password.js');
  await owner.query('BEGIN');
  await owner.query(`SELECT set_config('app.is_platform','true',true)`);
  const u = await owner.query(`INSERT INTO users (email, full_name, password_hash, status) VALUES ($1,'Owner A',$2,'ACTIVE') RETURNING id`, [email, await hashPassword('Pw-12345678')]);
  await owner.query(`INSERT INTO role_assignments (user_id, role_id, organization_id, scope_type, scope_id)
                     SELECT $1, id, $2, 'organization', $2 FROM roles WHERE code='institution_owner'`, [u.rows[0].id, ids.orgA]);
  await owner.query('COMMIT');
  const l = await call('POST', '/v1/auth/login', undefined, { email, password: 'Pw-12345678' });
  ownerA = l.body.access_token;

  assert.equal((await call('POST', `/v1/organizations/${ids.orgA}/campuses`, ownerA, { code: 'MAIN', name: 'Main Campus' })).status, 201);
  assert.equal((await call('POST', `/v1/organizations/${ids.orgA}/campuses`, ownerA, { code: 'MAIN', name: 'Dup' })).status, 409);
  assert.equal((await call('POST', `/v1/organizations/${ids.orgB}/campuses`, ownerA, { code: 'X', name: 'Nope' })).status, 403);
  assert.equal((await call('GET', `/v1/organizations/${ids.orgB}`, ownerA)).status, 403);
  assert.equal((await call('POST', '/v1/organizations', ownerA, { name: 'Rogue', slug: `r-${uniq}`, type: 'school' })).status, 403);
  assert.equal((await call('POST', `/v1/organizations/${ids.orgA}/campuses`, undefined, { code: 'Z', name: 'Anon' })).status, 401);
  assert.equal((await call('POST', `/v1/organizations/${ids.orgA}/campuses`, ownerA, { code: '', name: 'x' })).status, 422);

  const list = await call('GET', '/v1/organizations', ownerA);
  assert.deepEqual(list.body.data.map((o: { id: string }) => o.id), [ids.orgA]);
});

T('Postgres RLS blocks cross-tenant reads even if app code forgets a filter', async () => {
  assert.equal((await call('POST', `/v1/organizations/${ids.orgB}/campuses`, admin, { code: 'BMAIN', name: 'B Main' })).status, 201);
  const { withTx } = await import('./platform/db.js');
  const seenAsA = await withTx({ orgId: ids.orgA }, async (c) => (await c.query('SELECT DISTINCT organization_id FROM campuses')).rows);
  assert.deepEqual(seenAsA.map((r) => r.organization_id), [ids.orgA]);
  const noCtx = await withTx({}, async (c) => (await c.query('SELECT count(*)::int n FROM campuses')).rows[0].n);
  assert.equal(noCtx, 0); // no tenant context => no rows (fail closed)
  await assert.rejects(withTx({ orgId: ids.orgA }, (c) =>
    c.query(`INSERT INTO campuses (organization_id, code, name) VALUES ($1,'HACK','x')`, [ids.orgB])));
});

T('audit log is append-only at two layers (RLS for app role, trigger for owner)', async () => {
  const { withPlatformTx } = await import('./platform/db.js');
  // Layer 1: app role has no UPDATE/DELETE policy on audit_log, so it can never touch a row.
  const upd = await withPlatformTx((c) => c.query(`UPDATE audit_log SET action='tampered'`));
  const del = await withPlatformTx((c) => c.query(`DELETE FROM audit_log`));
  assert.equal(upd.rowCount, 0);
  assert.equal(del.rowCount, 0);
  await assert.rejects(withPlatformTx((c) => c.query(`TRUNCATE audit_log`)), /permission denied/);
  // Layer 2: even the owner/superuser (bypasses RLS) is stopped by the immutability trigger.
  await assert.rejects(owner.query(`UPDATE audit_log SET action='tampered'`), /append-only/);
  await assert.rejects(owner.query(`DELETE FROM audit_log`), /append-only/);
  const { rows } = await owner.query(`SELECT action FROM audit_log WHERE organization_id=$1 ORDER BY id`, [ids.orgA]);
  assert.deepEqual(rows.map((r) => r.action), ['organization.created', 'campus.created']);
});

T('refresh rotates token; logout revokes session', async () => {
  const l = await call('POST', '/v1/auth/login', undefined, { email: process.env.SEED_ADMIN_EMAIL, password: process.env.SEED_ADMIN_PASSWORD });
  const r1 = await call('POST', '/v1/auth/refresh', undefined, { refresh_token: l.body.refresh_token });
  assert.equal(r1.status, 200);
  assert.equal((await call('POST', '/v1/auth/refresh', undefined, { refresh_token: l.body.refresh_token })).status, 401);
  assert.equal((await call('POST', '/v1/auth/logout', r1.body.access_token)).status, 204);
  assert.equal((await call('GET', '/v1/me', r1.body.access_token)).status, 401);
});

T('health, readiness and request-id correlation', async () => {
  assert.equal((await call('GET', '/health')).status, 200);
  assert.equal((await call('GET', '/ready')).status, 200);
  const r = await call('GET', '/v1/me', undefined, undefined, { 'x-request-id': 'req-abc' });
  assert.equal(r.headers['x-request-id'], 'req-abc');
  assert.equal(r.body.error.request_id, 'req-abc');
});
