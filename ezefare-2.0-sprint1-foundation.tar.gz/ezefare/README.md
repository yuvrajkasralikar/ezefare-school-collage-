# EZEFare 2.0

Multi-tenant school & college platform — implementation of **EZEFare 2.0 Master System Blueprint v1.0** (frozen baseline).
Architecture decisions live in `docs/adr/`. Material changes require a Change Request (blueprint §32).

## Run locally
```bash
cp .env.example .env            # edit secrets
docker compose up -d            # Postgres 16 (+ non-superuser app role) and Redis
npm install
set -a; . ./.env; set +a
npm run migrate && npm run seed:dev
npm run dev                     # http://localhost:4000/health
npm test                        # unit tests (no DB)
npm run test:int -w @ezefare/api  # integration tests (needs DB + INTEGRATION env, see CI)
```

## Sprint 1 (blueprint §35) status
| # | Item | Status |
|---|------|--------|
| 1 | Monorepo + branching | Done (npm workspaces; protected-branch rules to set in GitHub) |
| 2 | Local / dev / staging environments | Local done; dev & staging need hosting decision |
| 3 | Tenant / organization / campus / scope model | Done (migrations 0002, 0003; RLS) |
| 4 | IAM primitives | Done: users, roles, permissions, scoped assignments, sessions, JWT + rotating refresh. OTP table ready, endpoints next |
| 5 | Schema conventions + migrations | Done |
| 6 | Audit-log foundation | Done (append-only, 2 layers) |
| 7 | API standards | Done (versioning, errors, pagination, request IDs, idempotency) |
| 8 | Frontend design system + nav shell | Not started |
| 9 | Mobile app shells | Not started |
| 10 | CI/CD + test baseline | CI workflow written; not yet run on GitHub. CD pending environments |
| 11 | Observability baseline | Partial: structured logs, request IDs, /health, /ready. Metrics/tracing/alerts pending |
| 12 | ADRs | Done (6) |
| 13 | Next: Student & Guardian domain (Phase 1) | Next |

## Verified
Typecheck clean; 11 unit tests (RBAC scope matrix + Appendix B rules); 7 integration tests on real Postgres with the
non-superuser role (tenant isolation incl. RLS fail-closed, audit immutability, idempotency, token rotation, request-ID correlation).
