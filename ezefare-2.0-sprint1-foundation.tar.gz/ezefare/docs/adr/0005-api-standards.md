# ADR-0005: API standards

Status: Accepted (implements EZEFare 2.0 Blueprint v1.0 §18)

## Decision
Versioned /v1 REST; structured errors {error:{code,message,details,request_id}}; x-request-id correlation echoed on every response; zod validation (422); keyset pagination; Idempotency-Key on mutations (same key+different payload => 409), stored in the same transaction as the effect.

## Consequences
Event/payment/scan endpoints must reuse idempotent(). Concurrent first-use of one key relies on the PK and returns a conflict rather than double-executing.
