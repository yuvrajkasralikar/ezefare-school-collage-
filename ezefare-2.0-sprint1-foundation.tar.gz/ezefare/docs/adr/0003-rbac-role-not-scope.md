# ADR-0003: RBAC where role != scope

Status: Accepted (implements EZEFare 2.0 Blueprint v1.0 §3, Appendix B)

## Decision
Authority = role_assignment(role, scope_type platform|organization|campus|resource, scope_id, organization_id). authorize() is a pure function: permission must be granted AND scope must cover the fully resolved target AND the tenant must match. Parents, drivers, attendants and vendors use relationship rules (guardian link, trip assignment, vehicle ownership) via RelationshipRepo.

## Consequences
Permissions and role grants are data (migration 0005), changed via change-control. Callers must resolve organizationId on the target; missing org fails closed.
