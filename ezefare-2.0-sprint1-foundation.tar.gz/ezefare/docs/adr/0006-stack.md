# ADR-0006: Implementation stack (ASSUMPTION - confirm)

Status: Accepted (implements EZEFare 2.0 Blueprint v1.0 §15 (stack not specified))

## Decision
Node 22 + TypeScript + Fastify, PostgreSQL 16, Redis (compose-provisioned, not yet used), plain SQL migrations. The blueprint fixes architecture, not language; this is an engineering default.

## Consequences
Reversible while the codebase is small. Confirm or replace before Phase 1 depends on it.
