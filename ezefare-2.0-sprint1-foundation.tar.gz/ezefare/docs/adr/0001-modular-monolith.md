# ADR-0001: Modular monolith

Status: Accepted (implements EZEFare 2.0 Blueprint v1.0 §2, §16)

## Decision
One deployable API with explicit domain modules under apps/api/src/modules. Domains talk through application services/events, never by reaching into another domain's tables.

## Consequences
Fast to build and operate for the pilot. Extraction to services only when scale or isolation justifies it (Phase 11).
