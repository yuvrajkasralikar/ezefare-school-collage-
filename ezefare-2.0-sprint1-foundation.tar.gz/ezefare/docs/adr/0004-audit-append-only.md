# ADR-0004: Append-only audit log

Status: Accepted (implements EZEFare 2.0 Blueprint v1.0 §10, §22)

## Decision
audit_log is written in the same transaction as the change. App role has no UPDATE/DELETE policy (RLS) and an immutability trigger blocks UPDATE/DELETE/TRUNCATE even for the owner.

## Consequences
Failed logins are audited too. Retention/archival policy to be defined before production.
