# ADR-0002: Tenant isolation enforced in Postgres (RLS)

Status: Accepted (implements EZEFare 2.0 Blueprint v1.0 §2, §4)

## Decision
Every tenant table carries organization_id with FORCED Row Level Security keyed to per-transaction settings (app.current_org, app.is_platform) set by withTx(). The runtime DB role is non-superuser. Platform context is only available through the greppable withPlatformTx().

## Consequences
A forgotten WHERE clause cannot leak across tenants; no context means zero rows (fail closed). Migrations/seeds run as the owner role. A transaction holds one organization, so multi-org users act per-org via the org in the route path.
