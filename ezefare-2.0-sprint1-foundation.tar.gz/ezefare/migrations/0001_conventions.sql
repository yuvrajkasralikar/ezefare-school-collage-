-- DB conventions: uuid PKs, timestamptz, shared updated_at trigger, tenant helper.
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;

-- Tenant isolation predicate used by every RLS policy (blueprint §2: all protected data tenant-scoped).
-- app.current_org / app.is_platform are set per transaction by the API (see platform/db.ts).
CREATE OR REPLACE FUNCTION tenant_visible(org uuid) RETURNS boolean AS $$
  SELECT current_setting('app.is_platform', true) = 'true'
      OR (org IS NOT NULL AND org::text = current_setting('app.current_org', true));
$$ LANGUAGE sql STABLE;
