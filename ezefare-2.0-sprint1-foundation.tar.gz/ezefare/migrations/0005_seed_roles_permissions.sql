-- System roles (blueprint §3) and default permission grants. Grants are DEFAULTS and are data, not code;
-- changes go through change-control (blueprint §32).
INSERT INTO roles (code, name, interface) VALUES
 ('super_admin','EZEFare Super Admin','web'),
 ('institution_owner','Institution Owner','web'),
 ('admin','School/College Admin','web'),
 ('transport_manager','Transport Manager','web'),
 ('finance_manager','Finance Manager','web'),
 ('attendance_staff','Attendance/Admin Staff','web+mobile'),
 ('teacher','Teacher','web+mobile'),
 ('security_staff','Security Staff','web+mobile'),
 ('vendor_admin','Vendor Admin','web'),
 ('driver','Driver','mobile'),
 ('attendant','Attendant','mobile'),
 ('parent','Parent/Guardian','mobile'),
 ('student','Student (smartphone)','mobile');

INSERT INTO permissions (code, description) VALUES
 ('platform:admin','Platform-level operations across tenants'),
 ('org:manage','Create/modify organizations'),
 ('org:read','Read organization'),
 ('campus:manage','Create/modify campuses'),
 ('user:manage','Manage users'),
 ('role:manage','Manage role assignments'),
 ('student:read','Read students'),
 ('student:write','Create/modify students'),
 ('guardian:manage','Manage guardians and links'),
 ('card:manage','Issue/block/replace student cards'),
 ('academic:manage','Manage academic structure'),
 ('transport:manage','Manage routes, stops, trips, assignments'),
 ('vendor:manage','Manage vendors and contracts'),
 ('vehicle:manage','Manage vehicles/drivers/attendants'),
 ('trip:read','Read trips'),
 ('trip:operate','Operate assigned trips (scan, board, drop, SOS)'),
 ('tracking:read','Read live tracking'),
 ('attendance:read','Read attendance'),
 ('attendance:write','Mark/correct attendance'),
 ('safety:manage','Manage incidents and safety rules'),
 ('pickup:verify','Verify authorized pickup'),
 ('finance:manage','Manage fees, invoices, payments, refunds'),
 ('communication:manage','Manage templates and campaigns'),
 ('report:read','Read reports'),
 ('device:manage','Manage cards, readers and GPS devices'),
 ('subscription:manage','Manage subscriptions and plans'),
 ('audit:read','Read audit log'),
 ('self:read','Read own/linked data (relationship-checked)');

-- super_admin gets everything
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p WHERE r.code = 'super_admin';

WITH grants(role_code, perm_code) AS (VALUES
 ('institution_owner','org:read'),('institution_owner','campus:manage'),('institution_owner','user:manage'),
 ('institution_owner','role:manage'),('institution_owner','student:read'),('institution_owner','student:write'),
 ('institution_owner','guardian:manage'),('institution_owner','card:manage'),('institution_owner','academic:manage'),
 ('institution_owner','transport:manage'),('institution_owner','vendor:manage'),('institution_owner','vehicle:manage'),
 ('institution_owner','trip:read'),('institution_owner','tracking:read'),('institution_owner','attendance:read'),
 ('institution_owner','attendance:write'),('institution_owner','safety:manage'),('institution_owner','finance:manage'),
 ('institution_owner','communication:manage'),('institution_owner','report:read'),('institution_owner','device:manage'),
 ('institution_owner','audit:read'),
 ('admin','org:read'),('admin','student:read'),('admin','student:write'),('admin','guardian:manage'),
 ('admin','card:manage'),('admin','academic:manage'),('admin','attendance:read'),('admin','attendance:write'),
 ('admin','communication:manage'),('admin','report:read'),('admin','trip:read'),('admin','tracking:read'),
 ('transport_manager','transport:manage'),('transport_manager','vendor:manage'),('transport_manager','vehicle:manage'),
 ('transport_manager','trip:read'),('transport_manager','tracking:read'),('transport_manager','safety:manage'),
 ('transport_manager','device:manage'),('transport_manager','report:read'),('transport_manager','student:read'),
 ('finance_manager','finance:manage'),('finance_manager','report:read'),('finance_manager','student:read'),
 ('attendance_staff','attendance:read'),('attendance_staff','attendance:write'),('attendance_staff','student:read'),
 ('teacher','attendance:read'),('teacher','attendance:write'),('teacher','student:read'),
 ('security_staff','pickup:verify'),('security_staff','student:read'),
 ('vendor_admin','vehicle:manage'),('vendor_admin','trip:read'),
 ('driver','trip:operate'),('driver','trip:read'),
 ('attendant','trip:operate'),('attendant','trip:read'),
 ('parent','self:read'),('student','self:read'))
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM grants g JOIN roles r ON r.code = g.role_code JOIN permissions p ON p.code = g.perm_code;
